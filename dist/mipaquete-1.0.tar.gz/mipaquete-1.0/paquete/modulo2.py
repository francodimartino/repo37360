def funcion_modulo2():
    print("Hola, soy un módulo en el paquete modulo2")